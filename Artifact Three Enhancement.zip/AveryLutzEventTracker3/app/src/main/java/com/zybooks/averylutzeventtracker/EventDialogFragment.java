//--------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : When the user selects the option to create a new event within their
// account, this class is required to communicate the user's decisions within the
// displayed dialog box.
//--------------------------------------------------------------------------------

package com.zybooks.averylutzeventtracker;

import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class EventDialogFragment extends DialogFragment {

    // Host activity must implement
    public interface OnEventEnteredListener {
        void onEventEntered(String event);
    }

    private OnEventEnteredListener mListener;

    @NonNull
    @Override
    public AlertDialog onCreateDialog(Bundle savedInstanceState) {

        final EditText eventEditText = new EditText(getActivity());
        eventEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        eventEditText.setMaxLines(1);

        // Provide clear communications to the user regarding their choices.
        return new AlertDialog.Builder(requireActivity())
                .setTitle(R.string.event)
                .setView(eventEditText)
                .setPositiveButton(R.string.create, (dialog, whichButton) -> {
                    String subject = eventEditText.getText().toString();
                    mListener.onEventEntered(subject.trim());
                })
                .setNegativeButton(R.string.cancel, null)
                .create();
    }

    // Attach the created dialog to the dialog box.
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (OnEventEnteredListener) context;
    }
}