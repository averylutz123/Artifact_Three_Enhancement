//--------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : This Java class provides the ability to "get" and "set" variables
// that exist within the "User Account" database table. Thus, specific values can be
// retrieved from anywhere within the program in which these variables are needed.
// This Java class directly interacts with the database of the program.
//--------------------------------------------------------------------------------
package com.zybooks.averylutzeventtracker;

public class UserAccount {

    private String mUsername;
    private String mPassword;
    private String mPermission;
    private String mQuestionOne;
    private String mQuestionTwo;
    private String mQuestionThree;

    public String getUsername() {
        return mUsername;
    }
    public void setUsername(String username) {
        this.mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }
    public void setPassword(String password) { this.mPassword = password; }

    public String getPermission() {
        return mPermission;
    }
    public void setPermission(String permission) { this.mPermission = permission; }

    public String getQuestionOne() {
        return mQuestionOne;
    }
    public void setQuestionOne(String questionOne) { this.mQuestionOne = questionOne; }

    public String getQuestionTwo() {
        return mQuestionTwo;
    }
    public void setQuestionTwo(String questionTwo) { this.mQuestionTwo = questionTwo; }

    public String getQuestionThree() {
        return mQuestionThree;
    }
    public void setQuestionThree(String questionThree) { this.mQuestionThree = questionThree; }

}
