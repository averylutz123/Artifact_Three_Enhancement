//--------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : This database provides the foundation to all functionality within
// the program. This database stores all content related to the different user
// accounts, the different events, and the information associated with each event.
// Within the enhancements of the program, total CRUD functionality was given to
// each event that is added to the database so that the user can have a greater
// range of engagement.
//--------------------------------------------------------------------------------

package com.zybooks.averylutzeventtracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class EventDatabase extends SQLiteOpenHelper {

    // Create a name for the database so that it can be referenced throughout the program.
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "event.db";
    private static EventDatabase mEventDb;

    // Create the database upon application download.
    public static EventDatabase getInstance(Context context) {
        if (mEventDb == null) {
            mEventDb = new EventDatabase(context);
        }
        return mEventDb;
    }

    private EventDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Column names that are required for the Event Table.
    // Username will be a primary key to interact with UserAccounts.
    private static final class EventTable {
        private static final String TABLE = "events";
        private static final String COL_TEXT = "text";
        private static final String COL_UPDATE_TIME = "updated";
        private static final String COL_USERNAME = "username";
    }

    // Column names that are required for the Information Table.
    // ID will be the primary key to find specific information in table.
    private static final class InformationTable {
        private static final String TABLE = "information";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DATE = "date";
        private static final String COL_TIME = "time";
        private static final String COL_NOTIFY = "notify";
        private static final String COL_NOTES = "notes";
        private static final String COL_EVENT = "event";
    }

    // Column names that are required for the Login Table.
    // Username will be the primary key so that this table can interact with Event table.
    private static final class UserAccountTable {
        private static final String TABLE = "userAccount";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_PERMISSION = "permission";
        private static final String COL_QUESTION_ONE = "questionOne";
        private static final String COL_QUESTION_TWO = "questionTwo";
        private static final String COL_QUESTION_THREE = "questionThree";
    }

    // Create all the tables that will be used to store application data.
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create Event table that holds the names of all displayed events.
        db.execSQL("create table " + EventTable.TABLE + " (" +
                EventTable.COL_TEXT + " primary key, " +
                EventTable.COL_UPDATE_TIME + " int, " +
                EventTable.COL_USERNAME + ")");

        // Create Information table that holds the information associated with the events.
        db.execSQL("create table " + InformationTable.TABLE + " (" +
                InformationTable.COL_ID + " integer primary key autoincrement, " +
                InformationTable.COL_NAME + ", " +
                InformationTable.COL_DATE + ", " +
                InformationTable.COL_TIME + ", " +
                InformationTable.COL_NOTIFY + ", " +
                InformationTable.COL_NOTES + ", " +
                InformationTable.COL_EVENT + ", " +
                "foreign key(" + InformationTable.COL_EVENT + ") references " +
                EventTable.TABLE + "(" + EventTable.COL_TEXT + ") on delete cascade)");

        // Create User Account table that will hold each user's login information.
        db.execSQL("create table " + UserAccountTable.TABLE + " (" +
                UserAccountTable.COL_USERNAME + " primary key, " +
                UserAccountTable.COL_PASSWORD + ", " +
                UserAccountTable.COL_PERMISSION + ", " +
                UserAccountTable.COL_QUESTION_ONE + ", " +
                UserAccountTable.COL_QUESTION_TWO + ", " +
                UserAccountTable.COL_QUESTION_THREE + ") ");
    }

    // If the scheme of the database is changed, this method is called.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + EventTable.TABLE);
        db.execSQL("drop table if exists " + InformationTable.TABLE);
        db.execSQL("drop table if exists " + UserAccountTable.TABLE);
        onCreate(db);
    }

    // When the database is first opened, this method is called.
    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.setForeignKeyConstraintsEnabled(true);
        }
    }


    ////// METHODS PERTAINING TO THE USER ACCOUNT TABLE: register, log in, questions.//////

    // Create a list of each user accounts in which the list is ordered by username.
    // This list is retrieved upon the start of the program before users log in.
    public List<UserAccount> getAccounts() {
        List<UserAccount> accounts = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String orderBy = UserAccountTable.COL_USERNAME + " collate nocase";

        // Ensure all existing user accounts are called within this method.
        String sql = "select * from " + UserAccountTable.TABLE + " order by " + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                UserAccount userAccount = new UserAccount();
                userAccount.setUsername(cursor.getString(0));
                userAccount.setPassword(cursor.getString(1));
                userAccount.setPermission(cursor.getString(2));
                userAccount.setQuestionOne(cursor.getString(3));
                userAccount.setQuestionTwo(cursor.getString(4));
                userAccount.setQuestionThree(cursor.getString(5));
                accounts.add(userAccount);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return accounts;
    }

    // Insert new user accounts into the User Account table.
    public boolean insertUserAccount(UserAccount userAccount) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserAccountTable.COL_USERNAME, userAccount.getUsername());
        values.put(UserAccountTable.COL_PASSWORD, userAccount.getPassword());
        values.put(UserAccountTable.COL_PERMISSION, userAccount.getPermission());
        values.put(UserAccountTable.COL_QUESTION_ONE, userAccount.getQuestionOne());
        values.put(UserAccountTable.COL_QUESTION_TWO, userAccount.getQuestionTwo());
        values.put(UserAccountTable.COL_QUESTION_THREE, userAccount.getQuestionThree());
        long result = db.insert(UserAccountTable.TABLE, null, values);

        // The user cannot log in if they do not have an account.
        return result != -1;
    }

    // Edit the user account to include their permission preference.
    public UserAccount addPermission(String username, String permission) {
        UserAccount userAccount = null;

        // Ensure the permission being changed is associated with the correct account.
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserAccountTable.TABLE +
                " where " + UserAccountTable.COL_USERNAME+ " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { username });

        if (cursor.moveToFirst()) {
            userAccount = new UserAccount();
            userAccount.setUsername(cursor.getString(0));
            userAccount.setPassword(cursor.getString(1));
            userAccount.setPermission(permission);
            userAccount.setQuestionOne(cursor.getString(3));
            userAccount.setQuestionTwo(cursor.getString(4));
            userAccount.setQuestionThree(cursor.getString(5));
        }
        return userAccount;
    }

    // Edit user account to include the user's answer to security questions.
    public UserAccount addSecurityQuestions(String username, String questionOne,
                                            String questionTwo, String questionThree) {
        UserAccount userAccount = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserAccountTable.TABLE +
                " where " + UserAccountTable.COL_USERNAME+ " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { username });

        // Ensure only the security question fields are being changed.
        if (cursor.moveToFirst()) {
            userAccount = new UserAccount();
            userAccount.setUsername(cursor.getString(0));
            userAccount.setPassword(cursor.getString(1));
            userAccount.setPermission(cursor.getString(2));
            userAccount.setQuestionOne(questionOne);
            userAccount.setQuestionTwo(questionTwo);
            userAccount.setQuestionThree(questionThree);
        }
        return userAccount;
    }

    // When a user forgets their password, allow them to answer security questions.
    public UserAccount getUserPassword(String username, String questionOne,
                                       String questionTwo, String questionThree) {
        UserAccount userAccount = null;
        SQLiteDatabase db = this.getReadableDatabase();

        // All three security questions must be correct for a user to access their password.
        String sql = "select * from " + UserAccountTable.TABLE +
                " where " + UserAccountTable.COL_USERNAME + " = ?" + " and " + UserAccountTable.COL_QUESTION_ONE + " = ?"
                + " and " + UserAccountTable.COL_QUESTION_TWO + " = ?" + " and " + UserAccountTable.COL_QUESTION_THREE + " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { username,questionOne,questionTwo,questionThree});

        if (cursor.moveToFirst()) {
            userAccount = new UserAccount();
            userAccount.setUsername(cursor.getString(0));
            userAccount.setPassword(cursor.getString(1));
            userAccount.setPermission(cursor.getString(2));
            userAccount.setQuestionOne(cursor.getString(3));
            userAccount.setQuestionTwo(cursor.getString(4));
            userAccount.setQuestionThree(cursor.getString(5));
        }
        return userAccount;
    }


    // Each time a change is made to a user's account, this method is called.
    public void updateUserAccount(UserAccount userAccount){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserAccountTable.COL_USERNAME, userAccount.getUsername());
        values.put(UserAccountTable.COL_PASSWORD, userAccount.getPassword());
        values.put(UserAccountTable.COL_PERMISSION, userAccount.getPermission());
        values.put(UserAccountTable.COL_QUESTION_ONE, userAccount.getQuestionOne());
        values.put(UserAccountTable.COL_QUESTION_TWO, userAccount.getQuestionTwo());
        values.put(UserAccountTable.COL_QUESTION_THREE, userAccount.getQuestionThree());
        db.update(UserAccountTable.TABLE, values,
                UserAccountTable.COL_USERNAME + " = ?", new String[] { userAccount.getUsername() });
    }


    // Ensure the user has an account. Return whether they have an account or not.
    public boolean checkUsername(String username) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + UserAccountTable.TABLE +
                " where " + UserAccountTable.COL_USERNAME + " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { username });
        return cursor.getCount() > 0;
    }

    // When a user chooses to log in, make sure both username and password are correct.
    public boolean checkUsernamePassword(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + UserAccountTable.TABLE +
                " where " + UserAccountTable.COL_USERNAME + " = ?" + " and " + UserAccountTable.COL_PASSWORD + " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { username,password });
        return cursor.getCount() > 0;
    }

    // Get the permissions of someone who already has an account.
    // Get the information when a user chooses an event name.
    public UserAccount getUserAccount(String username) {
        UserAccount userAccount = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserAccountTable.TABLE +
                " where " + UserAccountTable.COL_USERNAME+ " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { username});

        if (cursor.moveToFirst()) {
            userAccount = new UserAccount();
            userAccount.setUsername(cursor.getString(0));
            userAccount.setPassword(cursor.getString(1));
            userAccount.setPermission(cursor.getString(2));
            userAccount.setQuestionOne(cursor.getString(3));
            userAccount.setQuestionTwo(cursor.getString(4));
            userAccount.setQuestionThree(cursor.getString(5));
        }
        return userAccount;
    }


    ////// METHODS PERTAINING TO THE EVENT TABLE: add, update, delete events.//////

    // Hold the list of events for different accounts. Event name, username, and update time.
    public List<Event> getEvents(String username) {
        List<Event> events = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + EventTable.TABLE +
                " where " + EventTable.COL_USERNAME + " = ?";
        //" order by " + orderBy;
        // Search by individual user names. Ensure correct events are selected.
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        if (cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setName(cursor.getString(0));
                event.setUpdateTime(cursor.getLong(2));
                event.setUsername(username);
                events.add(event);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return events;
    }

    // Get the information when a user chooses an event name.
    public Event getEvent(String eventName, String username) {
        Event event = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + EventTable.TABLE +
                " where " + EventTable.COL_TEXT + " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { eventName });

        if (cursor.moveToFirst()) {
            event = new Event();
            event.setName(cursor.getString(0));
            event.setUpdateTime(cursor.getLong(2));
            event.setUsername(username);
        }

        return event;
    }

    // Add events after the user taps the add event button.
    public boolean addEvent(Event event, String username) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventTable.COL_USERNAME, event.getUsername(username));
        values.put(EventTable.COL_TEXT, event.getName());
        values.put(EventTable.COL_UPDATE_TIME, event.getUpdateTime());
        long id = db.insert(EventTable.TABLE, null, values);
        return id != -1;
    }

    // Each time information is added or updated the entire event updates
    public void updateEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventTable.COL_TEXT, event.getName());
        values.put(EventTable.COL_UPDATE_TIME, event.getUpdateTime());
        db.update(EventTable.TABLE, values,
                EventTable.COL_TEXT + " = ?", new String[] { event.getName() });
    }

    // Allow users to delete event when no longer needed.
    public void deleteEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(EventTable.TABLE,
                EventTable.COL_TEXT + " = ?", new String[] { event.getName() });
    }

    ////// METHODS PERTAINING TO THE INFORMATION TABLE: add, update, delete information//////

    // Hold information for each event. Each information group is tied to an event.
    public List<Information> getInformationGroup(String subject) {
        List<Information> informationGroup = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + InformationTable.TABLE +
                " where " + InformationTable.COL_EVENT + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { subject });
        if (cursor.moveToFirst()) {
            do {
                Information information = new Information();
                information.setId(cursor.getInt(0));
                information.setName(cursor.getString(1));
                information.setDate(cursor.getString(2));
                information.setTime(cursor.getString(3));
                information.setNotify(cursor.getString(4));
                information.setNotes(cursor.getString(5));
                information.setEvent(cursor.getString(6));
                informationGroup.add(information);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return informationGroup;
    }

    // Get the information when a user chooses an event name.
    public Information getInformation(long informationId) {
        Information information = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + InformationTable.TABLE +
                " where " + InformationTable.COL_ID + " = ?";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[] { Float.toString(informationId) });

        if (cursor.moveToFirst()) {
            information = new Information();
            information.setId(cursor.getInt(0));
            information.setName(cursor.getString(1));
            information.setDate(cursor.getString(2));
            information.setTime(cursor.getString(3));
            information.setNotify(cursor.getString(4));
            information.setNotes(cursor.getString(5));
            information.setEvent(cursor.getString(6));
        }

        return information;
    }

    // Add new informaiton into an event category.
    public void addInformation(Information information) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InformationTable.COL_NAME, information.getName());
        values.put(InformationTable.COL_DATE, information.getDate());
        values.put(InformationTable.COL_TIME, information.getTime());
        values.put(InformationTable.COL_NOTIFY, information.getNotify());
        values.put(InformationTable.COL_NOTES, information.getNotes());
        values.put(InformationTable.COL_EVENT, information.getEvent());
        long informationId = db.insert(InformationTable.TABLE, null, values);
        information.setId(informationId);

        // Change update time in subjects table
        updateEvent(new Event(information.getEvent()));
    }

    // Method for when the user chooses to "edit" one of the event's information.
    public void updateInformation(Information information) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InformationTable.COL_ID, information.getId());
        values.put(InformationTable.COL_NAME, information.getName());
        values.put(InformationTable.COL_DATE, information.getDate());
        values.put(InformationTable.COL_TIME, information.getTime());
        values.put(InformationTable.COL_NOTIFY, information.getNotify());
        values.put(InformationTable.COL_NOTES, information.getNotes());
        values.put(InformationTable.COL_EVENT, information.getEvent());
        db.update(InformationTable.TABLE, values,
                InformationTable.COL_ID + " = " + information.getId(), null);

        // Change update time in event.table
        updateEvent(new Event(information.getEvent()));
    }

    // Method for when the user chooses to "delete" information.
    public void deleteInformation(long informationId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(InformationTable.TABLE,
                InformationTable.COL_ID + " = " + informationId, null);
    }

}