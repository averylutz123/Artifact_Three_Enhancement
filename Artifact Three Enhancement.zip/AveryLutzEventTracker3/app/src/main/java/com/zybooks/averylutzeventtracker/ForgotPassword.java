//------------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : If the user forgets their password, they can select the corresponding
// button on the login screen where they are directed to answer three security
// questions and must also enter their username. If the user's input to these security
// questions are correct, their password is revealed.
//------------------------------------------------------------------------------------

package com.zybooks.averylutzeventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ForgotPassword extends AppCompatActivity {
    private EditText mQuestionOneAnswer;
    private EditText mQuestionTwoAnswer;
    private EditText mQuestionThreeAnswer;
    private EditText mUsernameAnswer;
    private TextView mRevealPassword;
    private Button mEnterButton;
    private Button mBackButton;
    private EventDatabase mEventDb;
    private UserAccount mUserAccount;
    private String mUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        // Set the created variables to values entered by user in XML file.
        mUsernameAnswer = findViewById(R.id.usernameAnswer);
        mQuestionOneAnswer = findViewById(R.id.questionOneAnswer);
        mQuestionTwoAnswer = findViewById(R.id.questionTwoAnswer);
        mQuestionThreeAnswer = findViewById(R.id.questionThreeAnswer);
        mRevealPassword = findViewById(R.id.revealPassword);
        mEnterButton = findViewById(R.id.enterButton);
        mBackButton = findViewById(R.id.goBackButton);
        mEventDb = EventDatabase.getInstance(getApplicationContext());

        // Activate EnterButton with click listener so users can submit their answers.
        mEnterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameAnswer = mUsernameAnswer.getText().toString();
                String questionOneAnswer = mQuestionOneAnswer.getText().toString();
                String questionTwoAnswer = mQuestionTwoAnswer.getText().toString();
                String questionThreeAnswer = mQuestionThreeAnswer.getText().toString();
                String returnedPassword;

                // Ensure all questions are answered and that the username is entered.
                if (usernameAnswer.isEmpty() || questionOneAnswer.isEmpty() ||
                        questionTwoAnswer.isEmpty() || questionThreeAnswer.isEmpty()) {
                    Toast.makeText(ForgotPassword.this, R.string.enter_fields, Toast.LENGTH_SHORT).show();
                }
                // If not all values are correct, inform the user to try again.
                else {
                    mUserAccount = mEventDb.getUserPassword(usernameAnswer, questionOneAnswer,
                            questionTwoAnswer, questionThreeAnswer);
                    if (mUserAccount == null){
                        Toast.makeText(ForgotPassword.this, R.string.incorrectField, Toast.LENGTH_SHORT).show();
                    }
                    // Only reveal the password if all supplied informaiton is correct.
                    else {
                        returnedPassword = mUserAccount.getPassword();
                        mRevealPassword.setText("Your password:  " + returnedPassword);
                    }
                }
            }
        });

        // Take the user back to the login screen so they can log in.
        mBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), LoginScreen.class);
                startActivity(intent);
            }
        });
    }
}