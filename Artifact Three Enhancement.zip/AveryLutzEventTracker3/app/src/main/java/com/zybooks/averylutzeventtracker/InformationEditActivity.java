//---------------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : This screen is presented to the user when they choose to add new
// event information into the database or they would like to edit existing information.
// This screen acts as the "edit" mode for content that will later be displayed.
//---------------------------------------------------------------------------------------
package com.zybooks.averylutzeventtracker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class InformationEditActivity extends AppCompatActivity {

    public static final String EXTRA_INFORMATION_ID = "com.zybooks.averylutzeventtracker.information_id";
    public static final String EXTRA_EVENT = "com.zybooks.averylutzeventtracker.event";

    private EditText mEventName;
    private EditText mEventDate;
    private EditText mEventTime;
    private EditText mEventNotes;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch mEventNotify;
    private String mNotifactionText;

    private EventDatabase mEventDb;
    private long mInformationId;
    private Information mInformation;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information_edit);

        mEventName = findViewById(R.id.eventNameEdit);
        mEventDate = findViewById(R.id.eventDateEdit);
        mEventTime = findViewById(R.id.eventTimeEdit);
        mEventNotify = findViewById(R.id.notificationSwitch);
        mEventNotes = findViewById(R.id.eventNotesEdit);

        mNotifactionText = "off";
        mEventDb = EventDatabase.getInstance(getApplicationContext());

        // Get information ID from InformationActivity
        Intent intent = getIntent();
        mInformationId = intent.getLongExtra(EXTRA_INFORMATION_ID, -1);

        mEventNotify.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mNotifactionText = "on";
                }
                else {
                    mNotifactionText = "off";
                }
            }
        });


        if (mInformationId == -1) {
            // Add new information
            mInformation = new Information();
            setTitle(R.string.add_information);
        }
        else {
            // Update existing information
            mInformation = mEventDb.getInformation(mInformationId);
            mEventName.setText(mInformation.getName());
            mEventDate.setText(mInformation.getDate());
            mEventTime.setText(mInformation.getTime());
            mNotifactionText = mInformation.getNotify();
            mEventNotes.setText(mInformation.getNotes());

            mEventNotify.setChecked(mNotifactionText.equals("on"));

            setTitle(R.string.update_information);
        }

        String event = intent.getStringExtra(EXTRA_EVENT);
        mInformation.setEvent(event);
    }

    public void saveButtonClick(View view) {

        mInformation.setName(mEventName.getText().toString());
        mInformation.setDate(mEventDate.getText().toString());
        mInformation.setTime(mEventTime.getText().toString());
        mInformation.setNotify(mNotifactionText);
        mInformation.setNotes(mEventNotes.getText().toString());


        if (mInformationId == -1) {
            // New information
            mEventDb.addInformation(mInformation);
        } else {
            // Existing information
             mEventDb.updateInformation(mInformation);
        }

        // Send back information ID
        Intent intent = new Intent();
        intent.putExtra(EXTRA_INFORMATION_ID, mInformation.getId());
        setResult(RESULT_OK, intent);
        finish();
    }
}