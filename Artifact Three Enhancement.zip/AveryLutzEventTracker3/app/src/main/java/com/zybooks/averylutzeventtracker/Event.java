//--------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : This Java class provides the ability to "get" and "set" variables
// that exist within the "Event" database table. Thus, specific values can be
// retrieved from anywhere within the program in which these variables are needed.
// This Java class directly interacts with the database of the program.
//--------------------------------------------------------------------------------
package com.zybooks.averylutzeventtracker;

// Provide "get" and "set" functionality to variables in the Event table.
public class Event {

    // Declare the variables that will be required within this class.
    private String mUsername;
    private String mName;
    private long mUpdateTime;

    public Event() {}

    public Event(String name) {
        mName = name;
        mUpdateTime = System.currentTimeMillis();
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getUsername(String enteredName) {
        mUsername = enteredName;
        return mUsername;
    }

    public void setUsername(String username) { mUsername = username; }

    public long getUpdateTime() {
        return mUpdateTime;
    }

    public void setUpdateTime(long updateTime) {
        mUpdateTime = updateTime;
    }

}