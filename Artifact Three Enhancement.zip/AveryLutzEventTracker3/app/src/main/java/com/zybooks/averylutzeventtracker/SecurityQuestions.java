//--------------------------------------------------------------------------------
// Author    : Avery Lutz
// Date      : June, 19, 2022
// Artifact  : Three
// Course    : CS-499-T5649
// Purpose   : When a user first creates an account, they must now answer three
// security questions so they can obtain their password at a later date in case it is
// forgotten.
//--------------------------------------------------------------------------------

package com.zybooks.averylutzeventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SecurityQuestions extends AppCompatActivity {
    private EditText mQuestionOneAnswer;
    private EditText mQuestionTwoAnswer;
    private EditText mQuestionThreeAnswer;
    private Button mNextButton;
    private EventDatabase mEventDb;
    private UserAccount mUserAccount;
    private String mUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_questions);

        // Set the created variables to values entered by user in XML file.
        mQuestionOneAnswer = findViewById(R.id.questionOneAnswer);
        mQuestionTwoAnswer = findViewById(R.id.questionTwoAnswer);
        mQuestionThreeAnswer = findViewById(R.id.questionThreeAnswer);
        mNextButton = findViewById(R.id.nextButton);
        mEventDb = EventDatabase.getInstance(getApplicationContext());

        Intent intent = getIntent();
        mUsername = intent.getStringExtra("username");

        // Activate nextButton with click listener.
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String questionOneAnswer = mQuestionOneAnswer.getText().toString();
                String questionTwoAnswer = mQuestionTwoAnswer.getText().toString();
                String questionThreeAnswer = mQuestionThreeAnswer.getText().toString();

                // Ensure there are answers to all three security questions.
                if (questionOneAnswer.isEmpty() || questionTwoAnswer.isEmpty() ||
                        questionThreeAnswer.isEmpty()) {
                    Toast.makeText(SecurityQuestions.this, R.string.enter_fields, Toast.LENGTH_SHORT).show();
                }
                // If all answers are given, add them to the database.
                else {
                    mUserAccount = mEventDb.addSecurityQuestions(mUsername, questionOneAnswer,
                            questionTwoAnswer, questionThreeAnswer);
                    mEventDb.updateUserAccount(mUserAccount);

                    // Go to the Event List Activity.
                    Intent intent = new Intent(getApplicationContext(), EventListActivity.class);
                    intent.putExtra("username", mUsername);
                    startActivity(intent);
                }
            }
        });
    }
}